from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
import json
import os
from pathlib import Path
import sys

# Add the content/podcast directory to the path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'content', 'podcast'))

from podcast_backend import get_transcribe_podcast, get_summary_from_transcription

app = Flask(__name__, static_folder='frontend/build', static_url_path='')
CORS(app)

# Helper function to load podcasts from JSON files
def load_podcasts_from_json():
    """Load all podcast data from JSON files"""
    podcasts = {}
    content_dir = Path('content')
    
    if content_dir.exists():
        for json_file in content_dir.glob('podcast-*.json'):
            try:
                with open(json_file, 'r') as f:
                    data = json.load(f)
                    # Use podcast title as key
                    podcast_key = data['podcast_details']['podcast_title']
                    podcasts[podcast_key] = data
            except Exception as e:
                print(f"Error loading {json_file}: {e}")
    
    return podcasts

# API Routes

@app.route('/api/podcasts', methods=['GET'])
def get_podcasts():
    """Get all available podcasts"""
    try:
        podcasts = load_podcasts_from_json()
        return jsonify(podcasts)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/podcast/<podcast_title>', methods=['GET'])
def get_podcast_details(podcast_title):
    """Get specific podcast details"""
    try:
        podcasts = load_podcasts_from_json()
        if podcast_title in podcasts:
            return jsonify(podcasts[podcast_title])
        else:
            return jsonify({'error': 'Podcast not found'}), 404
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/transcribe', methods=['POST'])
def transcribe_podcast():
    """Transcribe a podcast from RSS feed URL"""
    try:
        data = request.get_json()
        rss_url = data.get('rss_url')
        
        if not rss_url:
            return jsonify({'error': 'RSS URL is required'}), 400
        
        # Call the transcription function from podcast_backend
        local_path = 'content/podcasts'
        result = get_transcribe_podcast(rss_url, local_path)
        
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/summarize', methods=['POST'])
def summarize_podcast():
    """Summarize podcast transcription"""
    try:
        data = request.get_json()
        transcription = data.get('transcription')
        
        if not transcription:
            return jsonify({'error': 'Transcription is required'}), 400
        
        # Call the summarization function from podcast_backend
        summary = get_summary_from_transcription(transcription)
        
        return jsonify({'summary': summary})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Serve React app
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_react_app(path):
    """Serve React app"""
    if path != "" and os.path.exists(os.path.join(app.static_folder, path)):
        return send_from_directory(app.static_folder, path)
    else:
        return send_from_directory(app.static_folder, 'index.html')

@app.errorhandler(404)
def not_found(e):
    """Serve React app on 404"""
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)
